Get heart dataset from http://medicaldecathlon.com/
Unzip dataset and locate it here